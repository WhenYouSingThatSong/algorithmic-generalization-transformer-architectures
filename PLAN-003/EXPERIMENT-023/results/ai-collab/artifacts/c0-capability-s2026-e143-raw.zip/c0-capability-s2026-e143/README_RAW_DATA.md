# C0 s2026/e143 capability raw data

Package created 2026-11-15 for review/GPT analysis. It contains the existing
s2026/e143 six-stratum C0 capability run that was previously left under `tmp/`.

## Identity

- weight: `s2026_e143`
- checkpoint: `tmp/runs/oldC0-newseed-150ep/checkpoints/Nodes32-ADD - L4H16D384_DeBERTa-seed-2026 - 2026-11-14-10:12:43/epoch=143-val_loss=0.0000.ckpt`
- checkpoint SHA256: `40babb206b1393d0892b047202b9d6469cd140c82f3ba82c96a466fa3c76e780`
- `run_meta.json` SHA256: `89c117b17d81d23fa7424f1274461076da3688d89243b7312d3b19eb08fb9c77`
- `index.jsonl` SHA256: `c57da32f83743a26e33e74e9bf8aa16bd9219727d5b42373c057c674c608494b`
- 384 graph NPZ, 64 rounds, GPU6, elapsed 95.19 s.
- Data: the same six fixed strata as `c0-capability-report.md`; their hashes
  are in `data_manifest.json` and repeated in `run/run_meta.json`.
- This is **e143**, not final e150 and not best-val e136. It was chosen to match
  the fixed-epoch protocol used for s42/s1234. No per-result checkpoint selection.

## Contents

```
c0-capability-s2026-e143/
├── run/                 384 graph NPZ, index.jsonl, run_meta.json
├── summary/summary-all3/ three-weight summary CSV (s2026 rows included)
├── docs/                s2026 report and four small CSVs
├── logs/s2026_e143.log  runner log
└── README_RAW_DATA.md
```

The run starts from the original input state; each round feeds hidden back
through the continuous `nointerm` path and decodes only for observation. See
`docs/c0-capability-s2026.md` for the schema and headline metrics.

## Boundaries

- Single seed and a fixed checkpoint; not a population or model-ranking result.
- 64 rounds is an exploratory cap and is far beyond the training loop depth.
- No C+ training, no hidden probe, no causal mechanism claim.
- The raw NPZ/index and summary should be treated as recorded data. The small
  committed CSVs are derived convenience tables, not a replacement for NPZ.
